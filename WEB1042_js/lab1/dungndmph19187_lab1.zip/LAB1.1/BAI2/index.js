function chan_le(n){
var n;
if(n%2==0){
    document.write(n +" là số chẵn"+"<br>")
}
else{
    document.write(n +" là số lẻ")
}
}