var r;
r=prompt("nhập giá trị cho r");
var c=2*r*Math.PI;
document.write("Bán kính hình tròn là: "+ r + "<br>")
document.write("Chu vi hình tròn là: "+ c)
