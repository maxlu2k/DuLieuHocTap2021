function thongtin() {
    document.getElementById("masv").innerHTML = "Masv: PH19187";
    document.getElementById("hoten").innerHTML = "Họ Tên: Nguyễn Đình Mạnh Dũng";
    document.getElementById("ngaysinh").innerHTML = "Ngày sinh: 6/11/2000";
    document.getElementById("quequan").innerHTML = "Quê quán: Hà Nội";
  }